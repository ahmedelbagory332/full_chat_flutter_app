<?php 
	define('DB_USERNAME','id17148266_root');
	define('DB_PASSWORD','Diff_android288');
	define('DB_NAME','id17148266_chat');
	define('DB_HOST','localhost');

	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY','AAAA8dn9fRw:APA91bG8EfxmQHbYWL0x5MA5ltRrjSfQgm1xGKPFTUmtOm6eutXT7GMXiPg1hVoQKQRaer93C1Jpyc8b_hjbLKf6Bn3BJD58YA9fjDNju66m1qOEDeCfcNz_JZcmMFuLOeKQlzTNkl3Z');

	