<?php 

class Push {
    //notification title
    private $title;

    //notification message 
    private $message;

    //notification image url 
    private $image;
    
     //notification peerUserId
    private $peerUserId;
    
     //notification peeredEmail 
    private $peeredEmail;
    
     //notification peeredName
    private $peeredName;
    
     //notification callType
    private $callType;

   

    //initializing values in this constructor
    function __construct($title, $message, $image, $peerUserId, $peeredEmail, $peeredName, $callType) {
         $this->title = $title;
         $this->message = $message; 
         $this->image = $image; 
         $this->peerUserId = $peerUserId; 
         $this->peeredEmail = $peeredEmail; 
         $this->peeredName = $peeredName; 
         $this->callType = $callType; 
    }
    
    //getting the push notification
    public function getPush() {
        $res = array();
        $res['data']['title'] = $this->title;
        $res['data']['message'] = $this->message;
        $res['data']['image'] = $this->image;
        $res['data']['peerUserId'] = $this->peerUserId;
        $res['data']['peeredEmail'] = $this->peeredEmail;
        $res['data']['peeredName'] = $this->peeredName;
        $res['data']['callType'] = $this->callType;
        return $res;
    }
 
}