<?php 
//importing required files 
require_once 'DbOperation.php';

$db = new DbOperation();

$response = array(); 

$isUpdated = $db->updateToken($_POST['email'],$_POST['token']);

 $_item = array( "response"=>$isUpdated);	 

echo json_encode($_item);