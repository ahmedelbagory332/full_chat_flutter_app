<?php 
	define('DB_USERNAME','your BD user name');
	define('DB_PASSWORD','your BD pass');
	define('DB_NAME','your BD name');
	define('DB_HOST','localhost');

	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY','your api key');

	
